package utils;

public class SortType {
	
	public static final SortType QUICKSORT = new SortType( "Quicksort" );
	public static final SortType BUBBLESORT = new SortType( "BubbleSort" );
	
	private String _sortType;
	
	private SortType( String sortType ) { _sortType = sortType; }
	
	public String toString() { return ( String.format( "SortType(%s)", _sortType ) ); }
	
}
