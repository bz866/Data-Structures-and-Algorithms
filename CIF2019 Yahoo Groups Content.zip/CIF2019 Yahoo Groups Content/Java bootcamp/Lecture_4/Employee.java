package employee;

public class Employee {

	protected int _age;
	protected String _name;
	protected String _employeeId;
	
	public Employee( String name, int age, String employeeId ) {
		_name = name;
		_age = age;
		_employeeId = employeeId;
	}
	
}
