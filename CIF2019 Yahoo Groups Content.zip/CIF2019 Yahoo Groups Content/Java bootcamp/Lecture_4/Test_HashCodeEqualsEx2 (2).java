package lecture3;

import java.util.HashSet;

import employee.Employee;
import employee.Employee1;

public class Test_HashCodeEqualsEx2 extends junit.framework.TestCase {

	public void test1() {
		
		String s1 = "Steve";
		String s2 = "Bob";
		assertFalse( s1 == s2 );
		assertFalse( s1.equals( s2 ) );
		
		Employee emp1 = new Employee( "Lee", 55, "3712" );
		Employee emp2 = new Employee( "Lee", 55, "3712" );
		assertTrue( emp1.equals( emp1 ) );
		assertFalse( emp1.equals( emp2 ) );
		
		s2 = new String( "Steve" );
		assertFalse( s1 == s2 );
		assertTrue( s1.equals( s2 ) );
		
		Employee emp3 = new Employee( "Bob", 49, "3713" );
		HashSet<Employee> set1 = new HashSet<Employee>();
		set1.add( emp1 );
		set1.add( emp2 );
		set1.add( emp3 );
		assertTrue( set1.size() == 3 );
		
		Employee1 empA = new Employee1( "Lee", 55, "3712" );
		Employee1 empB = new Employee1( "Lee", 55, "3712" );
		Employee1 empC = new Employee1( "Bob", 49, "3713" );
		HashSet<Employee1> set2 = new HashSet<Employee1>();
		set2.add( empA );
		set2.add( empB );
		set2.add( empC );
		assertTrue( set2.size() == 2 );
		assertTrue( set2.contains( empA ) );
		assertTrue( set2.contains( empB ) );
		assertTrue( set2.contains( empC ) );
		
	}
}
