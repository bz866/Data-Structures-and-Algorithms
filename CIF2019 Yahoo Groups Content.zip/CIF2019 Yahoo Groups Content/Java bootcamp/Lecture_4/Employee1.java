package employee;

public class Employee1 extends Employee {

	public Employee1(String name, int age, String employeeId) {
		super(name, age, employeeId);
	}
	
	@Override
	public boolean equals( Object o ) {
		if( ! ( o instanceof Employee ) )
			return false;
		if( o == this )
			return true;
		Employee otherEmployee = (Employee) o;
		return 
			( _name.equals( otherEmployee._name ) ) && 
			( _age == otherEmployee._age ) && 
			_employeeId.equals( otherEmployee._employeeId );
	}
	
	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + _name.hashCode();
		result = 31 * result + _age;
		result = 31 * result + _employeeId.hashCode();
		return result;
	}
}
