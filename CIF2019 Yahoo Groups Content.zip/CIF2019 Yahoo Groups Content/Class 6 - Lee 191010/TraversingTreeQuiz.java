package lecture191010;

import java.util.Iterator;
import java.util.TreeMap;
import java.util.TreeSet;

public class TraversingTreeQuiz extends junit.framework.TestCase {

	public void test1() {
		
		// Set up
		TreeSet<Integer> s = new TreeSet<Integer>();
		for( int i = 40; i < 60; i++ ) s.add( i );
		
		// Run
		Iterator<Integer> keyIterator = s.headSet( 49, false ).descendingIterator();
		for( int counter = 0; ( counter < 5 ) && keyIterator.hasNext(); counter++ )
			System.out.println( keyIterator.next() );
		
		// Set up
		TreeMap<Integer,Double> s1 = new TreeMap<Integer,Double>();
		for( int i = 40; i < 60; i++ ) s1.put( i, (double) i * 10 );
		
		// Run
		Iterator<Integer> keyIterator1 = s1.headMap( 49, false ).descendingKeySet().iterator();
		for( int counter = 0; ( counter < 5 ) && keyIterator1.hasNext(); counter++ )
			System.out.println( keyIterator1.next() );
		
	}
}
