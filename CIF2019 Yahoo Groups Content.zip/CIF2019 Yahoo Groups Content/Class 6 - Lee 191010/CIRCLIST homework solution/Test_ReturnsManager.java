package lecture190926;

import java.util.List;

public class Test_ReturnsManager extends junit.framework.TestCase {
	
	public void test1() {
	
		// Set up test
		ReturnsManager<Double>returnsManager = new ReturnsManager<Double>(200);
		for( int i = 0; i < 10; i++ ) {
			returnsManager.add( (double) i );
		}
		for( int i = 5; i < 10; i++ )
			for( int j = i; j < 10; j++ )
				returnsManager.add( (double) j );

		// Make sure test conditions are what we expect before we start test
		assertTrue( returnsManager._map.toString().equals( "{0.0=1, 1.0=1, 2.0=1, 3.0=1, 4.0=1, 5.0=2, 6.0=3, 7.0=4, 8.0=5, 9.0=6}" ) );
		// Get returns greater than 4.0D
		List<Double> result1 = returnsManager.getHigher( 4.0, 10 );
		assertTrue( result1.toString().equals( "[5.0, 5.0, 6.0, 6.0, 6.0, 7.0, 7.0, 7.0, 7.0, 8.0]" ) );
		// Get returns less than 6.0D
		List<Double> result2 = returnsManager.getLower( 6.0, 10 );
		assertTrue( result2.toString().equals( "[5.0, 5.0, 4.0, 3.0, 2.0, 1.0, 0.0]" ) ); 
	}

}
