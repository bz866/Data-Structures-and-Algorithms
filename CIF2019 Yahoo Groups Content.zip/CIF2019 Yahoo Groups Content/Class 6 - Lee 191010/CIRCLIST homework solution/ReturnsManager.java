package lecture190926;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;

public class ReturnsManager<T> {
	
	protected CircularList<T>    _queue;
	protected TreeMap<T,Integer> _map;
	protected int                _maxQSize;

	public ReturnsManager( int maxQSize ) {
		_queue = new CircularList<T>( maxQSize );
		_map = new TreeMap<T,Integer>();
		_maxQSize = maxQSize;
	}
	
	/** Increment new value's counter in our tree. 
	 *  If queue is full, remove oldest value from 
	 *  our queue and decrement its counter in our 
	 *  tree. If a value's counter in our tree is
	 *  zero, remove the entry in our tree.
	 */
	public void add( T newValue ) {
		Integer counter = _map.get( newValue );
		if( counter == null )
			_map.put( newValue, 1 );
		else
			_map.put( newValue, counter + 1 );
		
		if( _queue.size() == _maxQSize ) {
			T oldValue = _queue.removeFirst();
			Integer oldCounter = _map.get( oldValue );
			if( oldCounter == 1 )
				_map.remove( oldValue );
			else
				_map.put( oldValue, oldCounter - 1 );
		}
		_queue.addLast( newValue );
	}
	
	/** Iterate over some collection gathering returns for our results list **/
	protected List<T> get( 
		Iterator<Entry<T,Integer>> mapIterator, // An iterator that will walk through our map 
		int numReturns 
	) {
		LinkedList<T> results = new LinkedList<T>();
		while( mapIterator.hasNext() ) {
			Entry<T,Integer> entry = mapIterator.next();
			int nValuesToGet = Integer.min(
				( numReturns - results.size() ), // Max number of returns we need
				entry.getValue() // Number of returns in this bin
			);
			for( int i = 0; i < nValuesToGet; i++ )
				results.addLast( entry.getKey() );
		}
		return results;
	}
	
	/** Make an iterator that walks through our map in the higher
	 *  direction and call this.get to do the actual collection of
	 *  values **/
	public List<T> getHigher( T referenceReturn, int numReturns ) {
		boolean includeReferenceReturn = false;
		return this.get(
			_map.tailMap( referenceReturn, includeReferenceReturn )
				.entrySet()
				.iterator(),
			numReturns
		);
	}
	
	/** Make an iterator that walks through our map in the lower
	 *  direction and call this.get to do the actual collection of
	 *  values **/
	public List<T> getLower( T referenceReturn, int numReturns ) {
		boolean includeReferenceReturn = false;
		return this.get(
			_map.headMap( referenceReturn, includeReferenceReturn )
				.descendingMap().
				entrySet().
				iterator(),
			numReturns
		);
	}
	
}
