package ga;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class GA {
	
	/** A list of Crs - chromosomes of bit strings - that
	 *  represent the candidate solutions of this GA. 
	 */
	protected ArrayList<Cr> _population;
	
	/** An object that the GA can query to obtain the
	 *  parameters of this search such as the size of the
	 *  population, the stopping criteria, and so on. The
	 *  object also has a method for computing fitness.
	 */
	protected I_EvalObject _evalObject;
	
	/** A counter for determining the current generation */
	protected int _iGen;
	
	/** The number of bits required to represent the dimensions
	 *  of the GA's problem.
	 */
	protected int[] _numBitsPerDim;
	
	/** The best fitness achieved thus far */
	protected double _bestFitness;
	
	/** The generation in which the best fitness was achieved */
	protected int _bestFitnessGen;
	
	/** Compute self similarity */
	public float selfSim( ArrayList<Cr> population ) {
		int crLen = population.get( 0 ).getGenes().length();
		float selfSim = 0f;
		for( int iCol = 0; iCol < crLen; iCol++ ) {
			float colSum = 0;
			for( Cr cr : population )
				colSum += cr.getGenes().charAt( iCol ) == '1' ? 1 : 0;
			colSum /= population.size();
			selfSim += colSum < 0.5f ? 1.0f - colSum : colSum;
		}
		selfSim /= population.get( 0 ).getGenes().length();
		return selfSim;
	}
	
	/** This method will use a tournament selection to
	 *  choose a Cr for mating. The selection method that
	 *  often appears in explanations of GAs is called
	 *  roulette selection. That's where the chance that
	 *  a given CR is chosen is determined by its fitness
	 *  as a fraction of the sum of all fitness values.
	 *  However, this method is computationally slow. A
	 *  method that achieves nearly the same result is
	 *  called tournament selection. It works as follows.
	 *  
	 *  n Crs are chosen at random from the population.
	 *  The one with the highest fitness wins the
	 *  tournament and is chosen for selection. For
	 *  example, if n = 2, we choose two Crs at random,
	 *  determine which one has the higher fitness, and
	 *  return it as our selection. This method will be
	 *  called twice to get 2 Crs that will then be
	 *  spliced with each other.
	 * 
	 * @param n The number of Crs with which to run the
	 *          tournament.
	 * @return One Cr that has been chosen for mating.
	 */
	protected Cr tournamentSelect( int n ) {
		int bestFitnessIndex = RandomGenerator.getInstance().nextInt( _population.size() );
		double bestFitness = _population.get( bestFitnessIndex ).getFitness();
		for( int j = 1; j < n; j++ ) {
			int index = RandomGenerator.getInstance().nextInt( _population.size() );
			if( _population.get( index ).getFitness() > bestFitness ) {
				bestFitnessIndex = index;
				bestFitness = _population.get( index ).getFitness();
			}
		}
		return _population.get( bestFitnessIndex );
	}
	
	/** Method used to splice two Crs together to create an
	 *  offspring. Note that there may be more than one
	 *  point at which the two will be spliced. This
	 *  method chooses the splice points and the Crs
	 *  do the actual splicing. 
	 *  
	 * @param cr1
	 * @param cr2
	 * @return A new offspring Cr
	 */
	protected Cr splice( Cr cr1, Cr cr2 ) {
		int[] splicePoints = new int[ _evalObject.getNumSplicePoints() ];
		for( int i = 0; i < _evalObject.getNumSplicePoints(); i++ )
			splicePoints[ i ] = (int)(
				RandomGenerator.getInstance().nextFloat() * 
				cr1.getGenes().length()
			);
		Arrays.sort( splicePoints );
		return cr1.spliceWith( cr2, splicePoints );
	}
	
	/** Creates a new population of candidate Crs by 1) saving
	 *  the required number of best solutions, and 2) using
	 *  tournament selection - selection in proportion to 
	 *  fitness - to splice together Crs until a newly created
	 *  population is the same size as the old population. 
	 */
	public void repopulate() {
		
		// Note that the right way to do this is to keep two
		// array lists and re-use the discarded ones as we
		// alternate between them. That would obviate the
		// object creation we are doing here.
		ArrayList<Cr> newPopulation = new ArrayList<Cr>( _population.size() );
		
		// Add best solutions of last population
		int numBestToSave = _evalObject.getNumBestToSave();
		for( int i = 0; i < numBestToSave; i++ )
			newPopulation.add( _population.get( i ) );
		
		// To fill out the rest of the new population,
		// perform tournament selection and cross the
		// selected Cr's.
		while( newPopulation.size() < _population.size() ) {
			Cr cr1 = tournamentSelect( 2 );
			Cr cr2 = tournamentSelect( 2 );
			Cr offspring = this.splice( cr1, cr2 );
			newPopulation.add( offspring );
		}
		_population = newPopulation;
	}
	
	/** Save the eval object and determine the number of
	 *  bits that will be require in each dimension. 
	 * @param evalObject The object that will be used to tell the GA
	 *                   about the parameters of the search, including
	 *                   the fitness function.
	 */
	public GA( I_EvalObject evalObject ) {
		
		// Save the evalObject which is the GA's connection
		// to the actual problem.
		_evalObject = evalObject;
		
		// Determine how many bits we will need in 
		// each dimension of our problem.
		_numBitsPerDim = new int[ _evalObject.getDimSizes().length ];
		for( int i = 0; i < _evalObject.getDimSizes().length; i++ )
			_numBitsPerDim[ i ] = (int)Math.ceil( Math.log( _evalObject.getDimSizes()[ i ] ) / Math.log( 2.0D ) );
	}
	
	/** Get ready to run the GA */
	protected void resetVariables() {
		_population = new ArrayList<Cr>();
		_iGen = -1;
		_bestFitness = 0;
		_bestFitnessGen = -1;
	}
	
	/** Call the eval object's computeFitness function for
	 *  the entire population of solutions. It will assign
	 *  a fitness to each. The population will then be
	 *  sorted by fitness so we can later make use of the
	 *  n best solutions.
	 */
	protected void computeFitness() {
		// Call the eval object to compute the fitness
		// of each Cr in the _population list.
		_evalObject.computeFitness( _population );
		
		// We will now sort the population by the fitness
		// of the Crs.
		_population.sort( 
			new Comparator<Cr>() {
				@Override
				public int compare(Cr o1, Cr o2) {
					return o2.getFitness().compareTo( o1.getFitness() );
				}
			}
		);
	}

	/** Translate from the string of a Cr to an
	 *  array of values in each dimension. These
	 *  values are unscaled so we will scale them
	 *  to the maximum value allowed by the number
	 *  of bits used to represent them. In other 
	 *  words, if we need 17 bits to represent a 
	 *  value between 0 and 69,999 inclusive (70,000
	 *  states), the maximum value of the bits is
	 *  2^17 or 131,072. We don't want values above
	 *  69,999, so we have to scale the candidate
	 *  values to our acceptable range.
	 * 
	 * @param numBitsPerDim An array that holds the number
	 *                      of bits required to represent
	 *                      a value in each dimension.
	 */
	protected void decodeAndRescale() {
		for( int i = 0; i < _population.size(); i++ ) {
			// Call the decode method of the i-th Cr in
			// the population to obtain an array of values,
			// one in each dimension of our solution space.
			int[] values = _population.get( i ).decode( _numBitsPerDim );
			// Now, scale these values to the maximum allowed.
			// (See long explanation in Javadoc above.)
			// The scaling is different in each dimension of
			// the problem so we must iterate through the
			// dimensions.
			int[] dimSizes = _evalObject.getDimSizes();
			for( int j = 0; j < dimSizes.length; j++ ) {
				// First, retrieve the maximum allowed value
				// for this dimension (dimension j).
				double dimSize = (double) dimSizes[ j ];
				
				// Now, retrieve the actual value that the
				// Cr decoded for this dimension.
				double valueInDim = (double) ( values[ j ] );
				
				// Now, compute the maximum possible states
				// that can be represented using the number
				// of bits we are using for this dimension.
				// Note that instead of doing the calculation 
				// on the fly, we can speed things up by 
				// doing the calculation up front and
				// leaving the values in a static array.
				double maxValInDim = Math.pow( 2.0, (double) _numBitsPerDim[ j ] ) - 1.0D;
				
				// We are ready to scale.
				// Remember that dimSize is the max value
				// allowed for this dimension.
				values[ j ] = (int) Math.floor(
					dimSize * valueInDim / maxValInDim
				);
			}
			
			// Save the decoded, scaled values.
			_population.get( i ).setValues( values);
		}
	}

	/** Build a random population of Crs */
	protected void initializePopulation( int[] numBitsPerDim ) {
		int popSize = _evalObject.getPopSize();
		for( int i = 0; i < popSize; i++ ) {
			
			// Instantiate a randomly generated Cr using
			// specifications of the number of bits in 
			// each dimension of our problem. Add it
			Cr cr = new Cr( numBitsPerDim );
			
			// Add new Cr to our population.
			_population.add( cr );
		}
	}

	/** Mutate - flip the bits - of some members of
	 *  the population. This lowers the chances that
	 *  the GA will get stuck in a local minima or
	 *  maxima.
	 *  
	 *  Note that We don't want to mutate the first 
	 *  n elements of the population because we 
	 *  deliberately saved them as best solutions from 
	 *  the previous generation. Hence, we start with
	 *  element n.
	 */
	protected void mutate() {
		float mutationRate = _evalObject.getMutationRate();
		for( int i = _evalObject.getNumBestToSave(); i < _population.size(); i++ )
			_population.get( i ).mutate( mutationRate );
	}
	
	/** Output the best solution we've found so far.
	 * 
	 * @param iGen A counter that tells us what generation the
	 *             GA is currently evaluating.
	 * @param iBestFitnessIndex An integer index into the array of Cr's.
	 *                          We can use it to retrieve the best Cr.
	 */
	protected void printBestFitness(int iGen ) {
		int [] values = _population.get( 0 ).getValues();
		int numDims = values.length;
		System.out.format( "%d\t%d", ++iGen, values[ 0 ] );
		for( int i = 1; i < numDims; i++ )
			System.out.format( ", %s", values[ i ] );
		System.out.print( "\n" );
	}
	
	/** Update generation counter and save new best
	 *  fitness if it is better than previous best
	 *  fitness.
	 */
	protected void updateStats() {
		_iGen++;
		double bestFitness = _population.get( 0 ).getFitness();
		if( bestFitness > _bestFitness ) {
			_bestFitnessGen = _iGen;
			_bestFitness = bestFitness;
		}
		
	}
	
	/**
	 * Returns true if either self similarity is above
	 * target self similarity or the best solution has
	 * not changed in a specified maximum number of
	 * generations.
	 *  
	 * @return true if one of the stopping criteria has
	 *         been achieved or false otherwise.
	 */
	protected boolean isReadyToStop() {
		return ( selfSim( _population ) >= _evalObject.getSelfSimTarget() )
			|| ( _iGen - _bestFitnessGen > _evalObject.getMaxProgressPause() );
	}

	/** Method called to start the GA search.
	 *  
	 *  Make an initially random population, evaluate its
	 *  fitness, select Crs for mating to re-populate,
	 *  probabilistically mutate some Crs and continue
	 *  loop until population achieves one of its
	 *  stopping criteria.
	 */
	public void go() {
		
		// Reset the generation counter and set up the
		// data structures to hold population and
		// related states.
		this.resetVariables();
		
		// Build random population.
		this.initializePopulation( _numBitsPerDim );
		
		// Loop until stopping criterion is achieved.
		while( true ) {
			
			// Decode population and rescale values.
			this.decodeAndRescale();
			
			// Compute fitness of each Cr in population.
			this.computeFitness();
			
			// Save stats for this generation, if any.
			this.updateStats();

			// Check for self similarity target threshold.
			if( this.isReadyToStop() )
				break;
			
			// Print out best fitness
			this.printBestFitness( _iGen );
			
			// Save best and repopulate using tournament selection
			this.repopulate();
			
			// Mutate some members of the population.
			this.mutate();
			
			
		} // while( true ) {...}
		
	} // public void go() {...}

	public ArrayList<Cr> getPopulation() {
		return _population;
	}
	
}