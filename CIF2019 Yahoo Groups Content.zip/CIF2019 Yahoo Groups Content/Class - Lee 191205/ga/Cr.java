package ga;

/**
 * Class representing a single chromosome - a single
 * candidate solution - in the population of a GA.
 * 
 * It handles the creation of a randomly generated
 * Cr, splicing Crs, decoding a Cr into integer
 * values representing one of a Cr's states, and
 * mutating Crs. It is also used to keep a fitness
 * and its decoded values in each of its dimensions.
 * 
 */
public class Cr {
	
	/** A string of 0's and 1's that represents this
	 *  Chromosome.
	 */
	protected String _genes;
	
	/** The fitness of this Cr */
	protected Double _fitness;
	
	/** The decoded, scaled values of this Cr in each
	 *  of its dimensions.
	 */
	protected int[] _values;

	/** Given an array of integer number of bits in each
	 *  dimension, instantiate a Cr class with the
	 *  appropriate number of randomly generated bits.
	 *  
	 * @param numBits An array of int values describing the
	 *                number of bits required to represent
	 *                each dimension of the problem.
	 */
	public Cr( int ... numBits ) {
		_fitness = null;
		_values = new int[ numBits.length ];
		int totalBits = 0;
		for( int n : numBits )
			totalBits += n;
		char[] str = new char[ totalBits ];
		for( int i = 0; i < totalBits; i++ )
			str[ i ] = RandomGenerator.getInstance().nextBoolean() ? '1' : '0';
		_genes = new String( str );
		// test yOuJbQ
	}
	
	/**
	 * Set the fitness of this Cr.
	 * 
	 * @param fitness The new fitness value of this Cr.
	 */
	public void setFitness( double fitness ) {
		_fitness = fitness;
	}
	/**
	 * @param values The decoded, scaled values of this Cr to which its
	 *               internal _values variable will be set. 
	 */
	public void setValues( int[] values ) {
		_values = values;
	}
	
	/** Construct a new chromosome from the string
	 *  of 0's and 1's that are its bits.
	 */
	public Cr( String str ) { _genes = str; } // eXAxIY
	
	/** Splice this candidate solution with cr using
	 *  breaks.
	 * @param cr
	 * @param breaks Splice points used to determine whether
	 *               this Chromosome's bits or the other 
	 *               Chromosome's bits are copied. E.g.
	 *               5, 8, 10 means that bits 0-4 come from
	 *               this Cr, bits 5-7 come from the other
	 *               Cr, bits 8-9 come from this Cr, and
	 *               bits 10 and on come from the other.
	 * @return The new Cr that results from the splice.
	 */
	public Cr spliceWith( Cr cr, int ... breaks ) {
		StringBuffer sb = new StringBuffer();
		int start = 0;
		String thisOne = this._genes;
		String otherOne = cr._genes;
		for( int i = 0; i < breaks.length; i++ ) {
			sb.append( thisOne.substring( start, breaks[ i ] ) );
			String temp = thisOne;
			thisOne = otherOne;
			otherOne = temp;
			start = breaks[ i ];
		}
		sb.append( thisOne.substring( start, thisOne.length() ) );
		return new Cr( sb.toString() );
		// test eXAxIY
	}

	/** For every bit, with the given prob, flip the bit from
	 *  0 to 1 or 1 to 0
	 * @param prob The probability of a flip
	 */
	public void mutate( float prob ) {
		// Note that the right way to do it is to figure out ahead
		// of time the number of mutations expected per chromosome
		// and the standard deviation of that number. Then we
		// can sample from the appropriate distribution to see
		// how many mutations there should be. For most
		// chromosomes, there will be none, so we can skip this
		// part entirely.
		StringBuffer sb = null;
		for( int i = 0; i < _genes.length(); i ++ )
			if( RandomGenerator.getInstance().nextFloat() < prob ) {
				if( sb == null )
					sb = new StringBuffer( _genes );
				sb.setCharAt(i, sb.charAt( i ) == '1' ? '0' : '1' );
			}
		if( sb != null )
			_genes = sb.toString();
		// test 5NqqlB
	}
	
	/**
	 * @return The string representation - 0s and 1s - of
	 *         this Cr.
	 */
	public final String getGenes() { return _genes; }
	
	/** Given the number of bits in each dimension,
	 *  decode the chromosome to produce an integer
	 *  value in each dimension. Note that these
	 *  values are unscaled. Only the eval object
	 *  can scale them to the proper range of
	 *  values.
	 *  
	 * @param dimSizesInBits An array of dimension size
	 *                       values
	 * @return An array of values in each dimension
	 */
	public int[] decode( int ... dimSizesInBits ) {
		int[] result = new int[ dimSizesInBits.length ];
		// Iterate through each dimension, using Integer.parseInt(...)
		// to convert strings of bits to int values.
		int start = 0;
		for( int i = 0; i < dimSizesInBits.length; i++ ) {
			result[ i ] = Integer.parseInt(
				_genes.substring( start, start + dimSizesInBits[ i ] ), 
				2 
			);
			start += dimSizesInBits[ i ];
		}
		return result;
		// test_5LFKdO
	}

	/** Return the fitness value of this Cr */
	public Double getFitness() {
		return _fitness;
	}
	
	/** Return this Cr's scaled values in each dimension. */
	public int[] getValues() { return _values; }
	
}